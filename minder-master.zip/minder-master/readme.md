# Build this project

1. npm install
2. npm run start:dev

N.B. nodejs and xampp should be installed. MySQL on xampp should run on port no 3306
